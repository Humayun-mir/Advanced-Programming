var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var multer = require('multer');
var upload = multer();
var mongoose = require('mongoose');
var session = require('express-session');

var admin = {
	admin_name: "admin",
	admin_pwd: "root"
}
var con = mongoose.connect('mongodb://localhost/product_manager',{ useNewUrlParser: true , useUnifiedTopology: true} );

var usersSchema = mongoose.Schema({
	username: String,
	pwd: String,
	userType: String,
})

var users = mongoose.model("users", usersSchema);

var productsSchema = mongoose.Schema({
	owner: String,
	pname: String,
	desc: String,
	price: Number,
})

var products = mongoose.model("products", productsSchema);

app.get('/login', function(req, res){
	res.render('login');
});

app.set('view engine', 'pug');
app.set('views','./views');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(upload.array());
app.use(express.static('public'));
app.use(session({secret: "secret"}));

var Users ={};
	users.find(function(err,res){
		console.log(res);
			Users = res; 
		});

var Products ={};

app.post('/login', function(req, res){
	var userInfo = req.body;
	if(userInfo.user == "admin"){
		if(userInfo.username == admin.admin_name && userInfo.pwd == admin.admin_pwd){
			req.session.user = admin;
			console.log(req.session);
			res.redirect('adminview');
		}
		else{
			res.render('login', {message: "Invalid username or password"});
		}
		
	}
	else{
		var flag = 0;
		for (var i = Users.length - 1; i >= 0; i--) { 
			if(Users[i].username == userInfo.username || Users[i].pwd == userInfo.pwd){
				req.session.user = Users[i];
				flag = 1;
				break;
			}
				
		}
		if(flag == 1){
				
		products.find({owner: req.session.user._id}, function(err, res){
			console.log(res);
			console.log(req.session);
			Products = res;
		})
		res.redirect('sellersview');

		}
	
	}
	app.get('/adminview', function(req, res){
	res.render('admin_view', {userslist:Users})
});
app.get('/sellersview', function(req, res){
	res.render('sellers_view', {
			name: req.session.user.username,
			productslist: Products
		})
});
	
});


app.post('/adduser', function(req, res){
	var userInfo = req.body;
	if(!userInfo.username || !userInfo.pwd || !userInfo.userType){
      res.render('admin_view', {message:"Please provide all the fields"})
   } else {
      var newUser = new users({
         username: userInfo.username,
         pwd: userInfo.pwd,
         userType: userInfo.userType
      });
		
      newUser.save(function(err, users){
         if(err)
            throw err;
         else
            console.log("User added");
      })
      Users.push(newUser);
      res.render('admin_view', {message2: "User has been successfully added", userslist: Users})
   }

});
app.post('/addproduct', function(req, res){
	console.log(req.session.user);
	var prodInfo = req.body;
	if(!prodInfo.pname || !prodInfo.desc || !prodInfo.price){
      res.render('sellers_view', {message:"Please provide all the fields"})
   } else {
      var newProd = new products({
      	 owner: req.session.user._id,
         pname: prodInfo.pname,
         desc: prodInfo.desc,
         price: prodInfo.price
      });
		
      newProd.save(function(err, products){
         if(err)
            throw err;
         else
            console.log('Product added');
      });
      Products.push(newProd);
      res.render('sellers_view', {message2: "New product has been succcessfully added", productslist:Products})
   }

});
var pid="";
app.get('/edit/:id', function(req,res,next){
	console.log(req.params.id);
	console.log("here2");
	pid = req.params.id;
});
app.post('/editproduct', function(req,res){
	var product=req.body;
	console.log(req.session.user);
	products.findByIdAndUpdate(pid,{pname:product.pname, desc:product.desc, price:product.price},function(err, res){
		console.log(res);
		products.find({owner:req.session.user._id}, function(err, response){
			if (err) throw err;
			console.log(response);
			console.log('here3');
			Products = response;
		});
		res.redirect('updatedProducts');
	})
});
app.get('/updatedProducts', function (req, res) {
	res.render('sellers_view', {message: "Your product has been updated", productslist: Products})
})
app.get('/delete/:id', function(req,res,next){
	console.log(req.params.id);
	console.log("here4");
	pid = req.params.id;
});
app.post('/deleteproduct', function(req,res){
	var product=req.body;
	console.log(req.session.user);
	products.findByIdAndRemove(pid,{pname:product.pname, desc:product.desc, price:product.price},function(err, res){
		console.log(res);
		products.find({owner:req.session.user._id}, function(err, res){
			console.log(res);
			console.log('here5');
			Products = res;
		});
		res.redirect('/updatedProducts');
	})
});
app.get('/updatedProducts', function (req, res) {
	res.render('sellers_view', {message: "Your product has been deleted", productslist: Products})
})

app.post('/logout', function(req,res){
	req.session.destroy(function(){
      console.log("user logged out.")
   });
   res.redirect('/login');
})

app.listen(3000);